This exercise is tricky and was removed from our recommendations because it mostly leverages regular expressions for the solution, and those aren't really taught at this point in our curriculum.

Leaving it here for posterity, or a good challenge for anyone that wants to give it a shot.

# Exercise XX - snakeCase

Convert phrases and words into snake case

> Snake case (or snake\_case) is the practice of writing compound words or phrases in which the elements are separated with one underscore character (\_) and no spaces, with each element's initial letter usually lowercased as in "foo\_bar" 

```javascript
snakeCase('Hello, World!') // hello_world
snakeCase('snakeCase') // snake_case
```
