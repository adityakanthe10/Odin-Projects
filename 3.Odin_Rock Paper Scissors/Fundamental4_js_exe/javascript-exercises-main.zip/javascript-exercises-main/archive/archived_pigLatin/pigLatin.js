function pigLatin(string) {

};
  
// Do not edit below this line
module.exports = pigLatin;
